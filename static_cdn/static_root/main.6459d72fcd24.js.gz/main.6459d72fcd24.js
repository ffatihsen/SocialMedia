
$(document).ready(function (){
        $('#modal-btn').click(function (){
            $('.ui.modal')
            .modal('show')
            ;
        })

        $('.ui.dropdown').dropdown()
    })